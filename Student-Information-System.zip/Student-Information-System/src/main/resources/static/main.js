// ===== Auth API =====
//

async function signup() {
    try {
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const course = document.getElementById('course').value;

        const data = await signupAPI(name, email, password, course);
        console.log(data); // ✅ check backend response
        const msg = document.getElementById('signupMessage');
        if(data.success) {
            msg.style.color = 'green';
            msg.innerText = 'Signup successful! Redirecting to login...';
            setTimeout(() => window.location.href = 'login.html', 1500);
        } else {
            msg.style.color = 'red';
            msg.innerText = data.message;
        }
    } catch(err) {
        console.error(err);
        alert('Something went wrong! Check console.');
    }
}


async function loginAPI(email, password) {
    const response = await fetch('http://localhost:8080/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    });
    return await response.json();
}

// ===== Attendance API =====
async function markAttendanceAPI(studentId, date, status) {
    const response = await fetch('http://localhost:8080/api/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ studentId, date, status })
    });
    return await response.json();
}

async function fetchAttendanceAPI(studentId) {
    const response = await fetch(`http://localhost:8080/api/attendance/by-student/${studentId}`);
    return await response.json();
}

// ===== Logout =====
function logout() {
    localStorage.removeItem('student');
    window.location.href = 'login.html';
}
