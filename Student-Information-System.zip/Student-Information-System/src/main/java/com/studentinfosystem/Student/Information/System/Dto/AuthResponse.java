package com.studentinfosystem.Student.Information.System.Dto;


public class AuthResponse {

    private String message;
    private boolean success;
    private StudentDto student;

    // -------- Constructors --------

    public AuthResponse() {
    }

    public AuthResponse(String message, boolean success, StudentDto student) {
        this.message = message;
        this.success = success;
        this.student = student;
    }

    // -------- Getters --------

    public String getMessage() {
        return message;
    }

    public boolean isSuccess() {
        return success;
    }

    public StudentDto getStudent() {
        return student;
    }

    // -------- Setters --------

    public void setMessage(String message) {
        this.message = message;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public void setStudent(StudentDto student) {
        this.student = student;
    }
}
