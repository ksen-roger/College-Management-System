package com.studentinfosystem.Student.Information.System.service;



import com.studentinfosystem.Student.Information.System.Dto.AttendanceRequest;
import com.studentinfosystem.Student.Information.System.models.Attendance;
import com.studentinfosystem.Student.Information.System.models.AttendanceStatus;
import com.studentinfosystem.Student.Information.System.models.Student;
import com.studentinfosystem.Student.Information.System.repository.AttendanceRepository;
import com.studentinfosystem.Student.Information.System.repository.StudentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final StudentRepository studentRepository;

    public AttendanceService(AttendanceRepository attendanceRepository,
                             StudentRepository studentRepository) {
        this.attendanceRepository = attendanceRepository;
        this.studentRepository = studentRepository;
    }

    @Transactional
    public Attendance markAttendance(Long studentId, LocalDate date, AttendanceStatus status) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new IllegalArgumentException("Student not found: " + studentId));

        // one attendance record per student per date - overwrite if exists
        Optional<Attendance> existing = attendanceRepository.findByStudentIdAndDate(studentId, date);
        Attendance attendance;
        if (existing.isPresent()) {
            attendance = existing.get();
            attendance.setStatus(status);
        } else {
            attendance = new Attendance(student, date, status);
        }
        return attendanceRepository.save(attendance);
    }

    public Attendance createAttendance(Attendance attendance) {
        return attendanceRepository.save(attendance);
    }

    public Optional<Attendance> findById(Long id) {
        return attendanceRepository.findById(id);
    }

    public List<Attendance> findByStudentId(Long studentId) {
        return attendanceRepository.findByStudentId(studentId);
    }

    public List<Attendance> findByDateRange(LocalDate start, LocalDate end) {
        return attendanceRepository.findByDateBetween(start, end);
    }

    public List<Attendance> findByStudentIdAndRange(Long studentId, LocalDate start, LocalDate end) {
        return attendanceRepository.findByStudentIdAndDateBetween(studentId, start, end);
    }

    public void deleteById(Long id) {
        attendanceRepository.deleteById(id);
    }
}