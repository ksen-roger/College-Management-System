package com.studentinfosystem.Student.Information.System.mapper;

import com.studentinfosystem.Student.Information.System.Dto.AttendanceResponse;
import com.studentinfosystem.Student.Information.System.models.Attendance;

public class AttendanceMapper {
    public static AttendanceResponse toDto(Attendance a) {
        AttendanceResponse r = new AttendanceResponse();
        r.setId(a.getId());
        r.setStudentId(a.getStudent().getId());
        r.setStudentName(a.getStudent().getName());
        r.setDate(a.getDate());
        r.setStatus(a.getStatus());
        r.setCreatedAt(a.getCreatedAt());
        return r;
    }
}
