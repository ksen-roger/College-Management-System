package com.studentinfosystem.Student.Information.System.Dto;
import com.studentinfosystem.Student.Information.System.models.Student;
import lombok.Data;

@Data
public class StudentDto {
    private String name;
    private String email;
    private String course;




    public StudentDto(Student student) {
        this.name = student.getName();
        this.email = student.getEmail();
        this.course = student.getCourse();
    }
    public StudentDto() {}
}
