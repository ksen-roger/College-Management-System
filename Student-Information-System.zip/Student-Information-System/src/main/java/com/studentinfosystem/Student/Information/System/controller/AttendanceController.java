package com.studentinfosystem.Student.Information.System.controller;

import com.studentinfosystem.Student.Information.System.Dto.AttendanceRequest;
//import com.studentinfosystem.Student.Information.System.Dto.attendance.dto.AttendanceResponse;
import com.studentinfosystem.Student.Information.System.Dto.AttendanceResponse;
import com.studentinfosystem.Student.Information.System.mapper.AttendanceMapper;
import com.studentinfosystem.Student.Information.System.models.Attendance;
import com.studentinfosystem.Student.Information.System.service.AttendanceService;
import jakarta.validation.Valid;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/attendance")
public class AttendanceController {

    private final AttendanceService service;

    public AttendanceController(AttendanceService service) {
        this.service = service;
    }

    // mark or create attendance
//    @PostMapping
//    public ResponseEntity<AttendanceResponse> markAttendance(@Valid @RequestBody AttendanceRequest req) {
//        Attendance saved = service.markAttendance(req.getStudentId(), req.getDate(), req.getStatus());
//        AttendanceResponse res = AttendanceMapper.toDto(saved);
//        return ResponseEntity.created(URI.create("/api/attendance/" + res.getId())).body(res);
//    }

    @PostMapping
    public ResponseEntity<AttendanceResponse> markAttendance(
            @Valid @RequestBody AttendanceRequest req) {

        Attendance saved = service.markAttendance(req.getStudentId(), req.getDate(), req.getStatus());
        AttendanceResponse res = AttendanceMapper.toDto(saved);

        return ResponseEntity.ok(res);
    }


    @GetMapping("/{id}")
    public ResponseEntity<AttendanceResponse> getById(@PathVariable Long id) {
        return service.findById(id)
                .map(a -> ResponseEntity.ok(AttendanceMapper.toDto(a)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // by student
    @GetMapping("/by-student/{studentId}")
    public ResponseEntity<List<AttendanceResponse>> getByStudent(@PathVariable Long studentId) {
        List<AttendanceResponse> list = service.findByStudentId(studentId)
                .stream().map(AttendanceMapper::toDto).collect(Collectors.toList());
        return ResponseEntity.ok(list);
    }

    // by date range, query params: from=2025-11-01&to=2025-11-30
    @GetMapping("/range")
    public ResponseEntity<List<AttendanceResponse>> getByRange(
            @RequestParam("from") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam("to") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {

        List<AttendanceResponse> list = service.findByDateRange(from, to)
                .stream().map(AttendanceMapper::toDto).collect(Collectors.toList());
        return ResponseEntity.ok(list);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}