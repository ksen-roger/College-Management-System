package com.studentinfosystem.Student.Information.System.repository;


import com.studentinfosystem.Student.Information.System.models.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {

    // Find student by email
    Optional<Student> findByEmail(String email);

    // Check if email exists
    boolean existsByEmail(String email);

    // Find students by course
    List<Student> findByCourse(String course);

    // Find students by name (case-insensitive)
    List<Student> findByNameContainingIgnoreCase(String name);

    // Find students by date of birth
    List<Student> findByDob(LocalDate dob);

    // Find students by date of birth between two dates
    List<Student> findByDobBetween(LocalDate startDate, LocalDate endDate);

    // Find students by course and name
    List<Student> findByCourseAndNameContainingIgnoreCase(String course, String name);

    // Find by email and password (for login)
    Optional<Student> findByEmailAndPassword(String email, String password);
}


