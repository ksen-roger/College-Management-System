package com.studentinfosystem.Student.Information.System.Dto;


public class SignupRequest {

    private String name;
    private String email;
    private String password;
    private String course;

    // -------- Constructors --------

    public SignupRequest() {
    }

    public SignupRequest(String name, String email, String password, String course) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.course = course;
    }

    // -------- Getters --------

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getCourse() {
        return course;
    }

    // -------- Setters --------

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setCourse(String course) {
        this.course = course;
    }
}

