package com.studentinfosystem.Student.Information.System.service;


import com.studentinfosystem.Student.Information.System.models.Student;
import com.studentinfosystem.Student.Information.System.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    // Get all students
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    // Get student by ID
    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    // Get student by email
    public Optional<Student> getStudentByEmail(String email) {
        return studentRepository.findByEmail(email);
    }

    // Get students by course
    public List<Student> getStudentsByCourse(String course) {
        return studentRepository.findByCourse(course);
    }

    // Search students by name
    public List<Student> searchStudentsByName(String name) {
        return studentRepository.findByNameContainingIgnoreCase(name);
    }

    // Get students by date of birth
    public List<Student> getStudentsByDob(LocalDate dob) {
        return studentRepository.findByDob(dob);
    }

    // Get students by date of birth range
    public List<Student> getStudentsByDobBetween(LocalDate startDate, LocalDate endDate) {
        return studentRepository.findByDobBetween(startDate, endDate);
    }

    // Check if email exists
    public boolean emailExists(String email) {
        return studentRepository.existsByEmail(email);
    }

    // Create new student
    public Student createStudent(Student student) {
        // Check if email already exists
        if (studentRepository.existsByEmail(student.getEmail())) {
            throw new IllegalArgumentException("Email already exists: " + student.getEmail());
        }
        return studentRepository.save(student);
    }

    // Update student
    public Student updateStudent(Long id, Student studentDetails) {
        Student student = studentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Student not found with id: " + id));

        // Check if email is being changed and if new email already exists
        if (!student.getEmail().equals(studentDetails.getEmail())
                && studentRepository.existsByEmail(studentDetails.getEmail())) {
            throw new IllegalArgumentException("Email already exists: " + studentDetails.getEmail());
        }

        student.setName(studentDetails.getName());
        student.setEmail(studentDetails.getEmail());
        student.setCourse(studentDetails.getCourse());
        student.setPhoneNumber(studentDetails.getPhoneNumber());
        student.setDob(studentDetails.getDob());

        return studentRepository.save(student);
    }

    // Delete student by ID
    public void deleteStudent(Long id) {
        if (!studentRepository.existsById(id)) {
            throw new IllegalArgumentException("Student not found with id: " + id);
        }
        studentRepository.deleteById(id);
    }

    // Delete all students
    public void deleteAllStudents() {
        studentRepository.deleteAll();
    }

    // Count total students
    public long countStudents() {
        return studentRepository.count();
    }

    // Check if student exists by ID
    public boolean studentExists(Long id) {
        return studentRepository.existsById(id);
    }
}
