package com.studentinfosystem.Student.Information.System.models;

public enum AttendanceStatus {
    PRESENT,
    ABSENT,
    LATE

}
