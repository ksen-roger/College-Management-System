package com.studentinfosystem.Student.Information.System.service;

import com.studentinfosystem.Student.Information.System.Dto.AuthResponse;
import com.studentinfosystem.Student.Information.System.Dto.LoginRequest;
import com.studentinfosystem.Student.Information.System.Dto.SignupRequest;
import com.studentinfosystem.Student.Information.System.Dto.StudentDto;
import com.studentinfosystem.Student.Information.System.mapper.StudentMapper;
import com.studentinfosystem.Student.Information.System.models.Student;
import com.studentinfosystem.Student.Information.System.repository.StudentRepository;
import com.studentinfosystem.Student.Information.System.utils.PasswordUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private StudentRepository studentRepository;

    // Student Signup
    public AuthResponse signup(SignupRequest request) {
        // Validate input
        if (request.getName() == null || request.getName().trim().isEmpty()) {
            return new AuthResponse("Name is required", false, null);
        }

        if (request.getEmail() == null || request.getEmail().trim().isEmpty()) {
            return new AuthResponse("Email is required", false, null);
        }

        if (!isValidEmail(request.getEmail())) {
            return new AuthResponse("Invalid email format", false, null);
        }

        if (request.getPassword() == null || !PasswordUtil.isValidPassword(request.getPassword())) {
            return new AuthResponse("Password must be at least 6 characters", false, null);
        }

        if (request.getCourse() == null || request.getCourse().trim().isEmpty()) {
            return new AuthResponse("Course is required", false, null);
        }

        // Check if email already exists
        if (studentRepository.existsByEmail(request.getEmail())) {
            return new AuthResponse("Email already registered", false, null);
        }

        // Create new student
        Student student = new Student();
        student.setName(request.getName());
        student.setEmail(request.getEmail());
        student.setPassword(PasswordUtil.hashPassword(request.getPassword()));
        student.setCourse(request.getCourse());
        student.setCreatedAt(LocalDateTime.now());

        // Save student
        Student savedStudent = studentRepository.save(student);

        // Convert to DTO using mapper
        StudentDto studentDto = StudentMapper.toDto(savedStudent);

        return new AuthResponse("Signup successful", true, studentDto);
    }

    // Student Login
    public AuthResponse login(LoginRequest request) {
        // Validate input
        if (request.getEmail() == null || request.getEmail().trim().isEmpty()) {
            return new AuthResponse("Email is required", false, null);
        }

        if (request.getPassword() == null || request.getPassword().trim().isEmpty()) {
            return new AuthResponse("Password is required", false, null);
        }

        // Find student by email
        Optional<Student> studentOptional = studentRepository.findByEmail(request.getEmail());

        if (studentOptional.isEmpty()) {
            return new AuthResponse("Invalid email or password", false, null);
        }

        Student student = studentOptional.get();

        // Verify password
        if (!PasswordUtil.verifyPassword(request.getPassword(), student.getPassword())) {
            return new AuthResponse("Invalid email or password", false, null);
        }

        // Update last login time
        student.setLastLogin(LocalDateTime.now());
        studentRepository.save(student);

        // Convert to DTO using mapper
        StudentDto studentDto = StudentMapper.toDto(student);

        return new AuthResponse("Login successful", true, studentDto);
    }

    // Email validation helper
    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return email.matches(emailRegex);
    }

    // Check if email exists
    public boolean emailExists(String email) {
        return studentRepository.existsByEmail(email);
    }

    // Get student by email
    public Optional<Student> getStudentByEmail(String email) {
        return studentRepository.findByEmail(email);
    }
}
