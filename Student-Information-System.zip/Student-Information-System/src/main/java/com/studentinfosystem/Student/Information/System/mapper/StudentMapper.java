package com.studentinfosystem.Student.Information.System.mapper;

import com.studentinfosystem.Student.Information.System.Dto.StudentDto;
import com.studentinfosystem.Student.Information.System.models.Student;

public class StudentMapper {

    // Convert Student Entity to StudentDto (without password)
    public static StudentDto toDto(Student student) {
        if (student == null) {
            return null;
        }

        StudentDto dto = new StudentDto();
        dto.setName(student.getName());
        dto.setEmail(student.getEmail());
        dto.setCourse(student.getCourse());

        return dto;
    }



    // Convert StudentDto to Student Entity
    public static Student toEntity(StudentDto dto) {
        if (dto == null) {
            return null;
        }

        Student student = new Student();

        student.setName(dto.getName());
        student.setEmail(dto.getEmail());
        student.setCourse(dto.getCourse());

        return student;
    }

    // Update existing Student entity from StudentDto
    public static void updateEntityFromDto(Student student, StudentDto dto) {
        if (student == null || dto == null) {
            return;
        }

        student.setName(dto.getName());
        student.setEmail(dto.getEmail());
        student.setCourse(dto.getCourse());
        // Note: ID is not updated as it's the primary key
    }
}
